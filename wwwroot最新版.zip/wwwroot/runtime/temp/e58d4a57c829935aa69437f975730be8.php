<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:71:"/storage/emulated/0/wwwroot/public/../application/index/view/index.html";i:1598257375;}*/ ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Home</title>
<link rel="stylesheet" type="text/css" href="/static/index/style.css"/>
<link href='http://fonts.googleapis.com/css?family=Raleway:400,200,300,600,700,800' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,700,800,600,300,200' rel='stylesheet' type='text/css'>
<link href="/static/index/css/font-awesome.min.css" rel="stylesheet" media="screen">
<link href="/static/index/css/responsive.css" rel="stylesheet" media="screen" type="text/css"/>
<link rel="stylesheet" href="/static/index/sidr/stylesheets/jquery.sidr.dark.css">
<script src="/static/index/js/jquery.min.js"></script>
<script src="/static/index/sidr/jquery.sidr.min.js"></script>
<script type="text/javascript" src="/static/index/js/smoothscroll.js"></script>

</head>
<body>
	<div class="header">
    	<div class="container">
    		<div class="logo-menu">
        		<div class="logo">
            		<h1><a href="#"><?php echo $web_title; ?></a></h1>
            	</div>
                <!--<a id="simple-menu" href="#sidr">Toggle menu</a>-->
                <div id="mobile-header">
<a class="responsive-menu-button" href="#"><img src="/static/index/images/11.png"/></a>
</div>
            	<div class="menu" id="navigation">
            		<ul>
                    	<li><a href="/">首页</a></li>
                        <li><a href="<?php echo url('search/Search/searchIndex'); ?>">搜题</a></li>
                        <li><a href="<?php echo url('collection/Collection/index'); ?>">搜集题目</a></li>

                        <li><a href="<?php echo url('user/Register/index'); ?>">用户注册</a></li>
                        <li><a href="<?php echo url('admin/Adminlogin/adminlogin'); ?>">管理员登录</a></li>
                        <li><a href="<?php echo url('user/User/login'); ?>">用户后台登录</a></li>
                    </ul>
            	</div>
        	</div>
        </div>
    </div>
    
    <div class="banner">
    	<div class="container">
        	<div class="header-text">
            	<p class="big-text">还在为不知怎么做有资源而不知怎么调用而发愁</p>
                <h2>总是四处找数据库资源接口，每年还要花费大量成本去用别人资源库吗？</h2>
                <p class="small-text">现在这款数据管理系统将会快速搭建起属于自己的资源管理系统!
                您可以用于搭建题库，学生成绩管理，数据存储管理等。</p>
                <div class="button-section">
                	<ul>
                    	<li><a href="https://fusong.lanzous.com/iHI3Pfcfsdi" class="top-button white">版本1.0下载</a></li>
                        <li><a href="http://www.xskj.store/source/114.html" class="top-button green">开发文档</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    
    <div class="color-border">
    </div>
    
    <div class="desc">
    	<div class="container">
        	<h2>一款轻量强大的数据管理系统</h2>
            <p>本程序依托于国内知名php框架thinkphp开发，安全而且高效，api接口调用迅速题库搜集渠道多样，让你更快速的搭建起属于自己题库系统.</p>
        </div>
    </div>
    <div class="features" id="features">
    	<div class="container">
        	<h3 class="text-head">我们 的 优势</h3>
        	<div class="features-section">
                <ul>
                	<li>
                    	<div class="feature-icon icon1"></div>
                     	<h4>资源收集多样</h4>
                        <p>我们采用多种资源数据搜集手段，让你不空有壳，而没有资源库资源而发愁</p>
                     </li>
                     <li>
                    	<div class="feature-icon icon2"></div>
                     	<h4>强大的数据库查询手段</h4>
                        <p>程序采用多种数据库查询手段，链式查询，模糊查询等，让你的用户更加精准定位所要题目答案，且结合多种补救查询手段。</p>
                     </li>
                     <li>
                    	<div class="feature-icon icon3"></div>
                     	<h4>强大的后台功能</h4>
                        <p>后台内置多种多样的功能，让你管理题库更加轻松，便捷。支付接口涵盖多种方式。各种拓展功能让你不再发愁。</p>
                     </li>
                </ul>
            </div>
        </div>
    </div>
    
    <div class="stories" id="stories">
    	<div class="container">
        	<h3 class="text-head">功能展示</h3>
            <p class="box-desc">后台集成多种支付，数据库管理，查询。漂亮美观的后台界面，是您最佳的选择，本程序完全开源免费。本程序所需网页空间不大，但需要有足够的数据库内存，大小取决于你所要搭建题库容量。</p>
        	<div class="stories-section">
            	<ul>
                	<li>
                    	<a href="#">
                    	<div class="story-img"><img src="/static/index/images/story1.png"/></div>
                        	<div class="story-box">
                            	<h4>后台展示</h4>
                        		<p>多种功能部署，强大且实用，界面美观大方.</p>
                        		
                            </div>
                        </a>
                    </li>
                    <li>
                    	<a href="#">
                    	<div class="story-img"><img src="/static/index/images/story2.png"/></div>
                        	<div class="story-box">
                            	<h4>数据库</h4>
                        		<p>采用单一+联合数据模式，多种查询技术手段，让您查询更加准确且快速。</p>
                        		
                            </div>
                        </a>
                    </li>
                    <li>
                    	<a href="#">
                    	<div class="story-img"><img src="/static/index/images/story3.png"/></div>
                        	<div class="story-box">
                            	<h4>多种调用查询接口</h4>
                        		<p>采用thinkphp搭建，让你的数据库更加安全。后台设置调用秘钥，让自己的数据库资源产生商业价值。</p>
                        		
                            </div>
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
   	
    <div class="contact" id="contact">
    	<div class="container">
        	<h3 class="text-head">给我们写信📝</h3>
            <p class="box-desc">每一天的精彩就是与你相遇.</p>
            	<div class="contact-section">
            		
                		<form>
                    		<input type="text" name="Name" placeholder="Name" />
                        	<input type="email" name="email" placeholder="Email"/>
                        	<textarea placeholder="Message" rows="6"></textarea>
                        	<button type="submit" class="submit">发送</button>
                   		</form>
                	
            	</div>
        </div>
    </div>
    <div class="color-border">
    </div>
    <div class="footer">
        	<div class="container">
            	<div class="infooter">
                <p class="copyright">
                <?php echo $web_copyright; ?> name All rights reserved.<a target="_blank" href="http://www.xskj.store/"><?php echo $web_beian; ?></a></p>
            	</div>
     <!--<a id="simple-menu" href="#sidr">Toggle menu</a>-       <ul class="socialmedia">
                <li><a href=""><i class="icon-twitter"></i></a></li>
                <li><a href=""><i class="icon-facebook"></i></a></li>
                <li><a href=""><i class="icon-dribbble"></i></a></li>
                <li><a href=""><i class="icon-linkedin"></i></a></li>
                <li><a href=""><i class="icon-instagram"></i></a></li>
            </ul><!--<a id="simple-menu" href="#sidr">Toggle menu</a>-->
            </div>
        </div>
        <script type="text/javascript" src="/static/index/js/jquery.nicescroll.min.js"></script>
        <script type="text/javascript">		
			 $(document).ready(function() {
				$('#simple-menu').sidr({
				side: 'right'
			});
			});
			$('.responsive-menu-button').sidr({
				name: 'sidr-main',
				source: '#navigation',
				side: 'right'

				});
			$(document).ready(
			function() {
			$("html").niceScroll({cursorborder:"0px solid #fff",cursorwidth:"5px",scrollspeed:"70"});
			}
			);
		</script>
</body>
</html>
