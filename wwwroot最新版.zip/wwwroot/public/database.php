<?php
$servername = "localhost";//所要连接数据库的服务器ip地址，本机一般为localhost
$username = "username";//用户名
$password = "userpassword";//数据库密码
$dbname = "mydata";//数据库名
?>