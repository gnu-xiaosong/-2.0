<?php
$servername = "47.75.78.216";
$username = "fsxz1314520";
$password = "fs123456";
$database="fsxz1314520";

$_sql = file_get_contents('localhost.sql');
$_arr = explode(';', $_sql);


/*
// 创建连接
$conn=mysqli_connect($servername, $username, $password,$database);
// 检测连接
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
*/

$conn =new mysqli($servername,$username,$password,$database);
// 判断是否连接成功
if ($conn->connect_error) {
    die("连接失败: " . $conn->connect_error);
} 
echo "连接成功";



//遍历执行sql语句
foreach ($_arr as $_value) {
$conn->query($_value.';');
}
$conn->close();
echo "successful";
$conn= null;
?>