<?php
echo date();