<?php
//框架引导文件
// 加载框架引导文件
require __DIR__ . '/thinkphp/start.php';